
public class Exam02 {

	public static void main(String[] args) {
		/* end키 -> 커서를 제일 우측으로
		 home키 -> 커서를 제일 좌측으로
		 한 줄 복사 -> 블럭지정 수 Ctrl + Alt + 방향키(아래나 위) */
		// 한 줄만 써야한느 상황에서는 한 줄 주석을
		// 여러줄에 걸쳐서 길게 주석 작성시는 /*내용*/ 여러줄 주석을 씁니다.
		System.out.println("a");
		System.out.println("HI Hello JAVA");
		System.out.println("100");
		System.out.println("100.0");
		System.out.println("false true");
	}
}
