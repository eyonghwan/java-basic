
public class Exam01 {

	public static void main(String[] args) {
		System.out.println("이름은 이용환입니다. ");
		System.out.println("전 자바를 배웁니다. ");
		System.out.println("\n오늘은 \"월요일\"입니다. ");
		System.out.println("행복지수는 120%이빈다. ");
	}

}
