
public class HelloJava {

	// 슬래시 2개를 덧붙인 이후에 적히는  내용은 주석입니다.
	// 주석은 코드에 대한 설명을 덧붙이는데 사용합니다.
	// 슬래시 없이 설명을 작성하면 에러가 납니다.
	
	// main이라고 적힌 하단의 중괄호 열린부분 ~ 닫힌부분의 사이의 코드만 실행됩니다.
	public static void main(String[] args) {
		// "적힌내용"을 콘솔이라고 불리는 창에 찍어줍니다.
		System.out.println("Hello World");
	}

}
