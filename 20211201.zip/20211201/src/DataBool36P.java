
public class DataBool36P {

	public static void main(String[] args) {
		// boolean 자료형은 참/거짓을 구분할 떄 씁니다.
		// 이 자료형의 변수에는 오직 true/false만 담을 수 있습니다.
		boolean a = true;
		boolean b = false;
		// boolean c =0; // 다른 언어와 다리 숫자로 참/거짓 표시 금지
		System.out.println(a);
		System.out.println(b);

	}

}
