package structure;

public class Cat {
	
	public String name;
	public int weight;
	public int height;
	
	//

}
