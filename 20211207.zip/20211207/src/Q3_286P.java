
public class Q3_286P {

	public static void main(String[] args) {
		
		int su01 = 5;
		int su02 = 4;
		
		int res = (su01 > su02) ? su01 + su02 : su02;
		System.out.println("res= "+res);
		

	}

}
