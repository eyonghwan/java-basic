
public class ThreeOperandQ1 {

	public static void main(String[] args) {
		// 먼저 int a를 선언하고 여러분이 원하는 숫자로 초기화해주세요.
		// 그 숫자가 100보다 크다면 "a는 100보다 큽니다."
		// 100보다 작거나 같다면 "a는 100보다 작거나 같습니다."
		// 라고 출력하는 삼항연산자를 아래에 작성해주세요.
		int a;
		a = 3650;
		System.out.println(
				(a>100) ? "a는 100보다 큽니다." : "a는 100보다 작거나 같습니다."
					);
	}

}
