
public class For01112P {

	public static void main(String[] args) {
		// for문은 while문과는 다르게 몇 바퀴 돌릴지 정해놓고
		// 사용하는 반복문입니다.
		// 문법은
		// for(시작변수; 종료조건; 증감식) {
		//		실행문1;
		//		실행문2...
		// }
		// 으로 이루어져 있습니다.
		for (int i = 0; i <2; i++) {
			System.out.println("for문을 이용한 반복문");
		}
			

	}

}
