
public class ForQ2112P {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
